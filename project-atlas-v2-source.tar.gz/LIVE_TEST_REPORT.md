# ProjectAtlas external live validation

Validation date: 2026-07-29
Runner: GitHub-hosted Ubuntu 24.04, Python 3.12.13
Workflow run: 30426423136
Result: PASSED

## Scope actually executed

The unmodified ProjectAtlas application was started with Uvicorn and a temporary SQLite database. The external runner then used the public REST API to submit and complete three analyses:

1. `https://github.com/ossf/scorecard`
   - GitHub repository API
   - ecosyste.ms repository API
   - OpenSSF Scorecard API
   - Status: completed, no provider errors

2. `pkg:pypi/fastapi@0.115.0`
   - PyPI JSON API
   - OSV query API
   - Status: completed, no provider errors

3. `https://example.com`
   - Real HTTPS page retrieval
   - Status: completed, HTTP 200

The same run also validated OpenAPI generation, persistence, status polling, report retrieval, MCP initialization, MCP tool listing, and MCP health calls.

## Important separation

Runner-specific packaging and diagnostics live under `validation/` and GitHub Actions. No DNS proxy, resolver override, transport bridge, or runner workaround was added to the `atlas/` application package.

See `LIVE_E2E_RESULTS.json` for the complete machine-readable evidence.
