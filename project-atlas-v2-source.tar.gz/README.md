# ProjectAtlas MVP

ProjectAtlas accepts a repository URL, PyPI URL/PURL, or ordinary webpage and creates a source-attributed analysis report.

## Run

```bash
uvicorn atlas.main:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000` or Swagger at `http://127.0.0.1:8000/docs`.

## API flow

```bash
RESOURCE=$(curl -s -X POST http://127.0.0.1:8000/v1/resources \
  -H 'content-type: application/json' \
  -d '{"input":"https://github.com/karakeep-app/karakeep"}')
```

Then POST `/v1/resources/{id}/analyses` and read `/v1/resources/{id}/report`.

## Live adapters

- GitHub REST API
- ecosyste.ms Repositories API
- OpenSSF Scorecard API
- PyPI JSON API
- OSV API
- Generic webpage fetch/title extraction

All providers fail independently. A partial report is retained when one provider is unavailable.

## Database

SQLite is the local default. Set `DATABASE_URL` to a SQLAlchemy PostgreSQL URL in production.

## Security defaults

Generic webpage analysis blocks private, loopback, link-local and reserved network targets by default to reduce SSRF risk. Set `ATLAS_ALLOW_PRIVATE_NETWORKS=true` only for controlled local testing.

## MCP for Codex

Run the stdio MCP server while the API is running:

```bash
python -m atlas.mcp_server
```

Tools: `resolve_resource`, `submit_and_analyze`, `get_report`, and `health`.
Set `ATLAS_API_URL` when the API is not on `http://127.0.0.1:8000`.
