# ProjectAtlas execution report

Date: 2026-07-29

## Executed locally

- FastAPI/Uvicorn server started on `127.0.0.1:8000`.
- Readiness endpoint returned HTTP 200.
- Swagger UI and OpenAPI schema returned HTTP 200.
- A separate real HTTP server served `e2e_site/sample.html` on port 8765.
- ProjectAtlas created the resource, queued and executed the analysis, fetched the page over HTTP, extracted the title and content metadata, saved observations in SQLite, and returned a completed report.
- Test suite: 6 passed.
- Python compile check passed.
- MCP initialize, tool listing, health, and full submit-and-analyze calls were executed over stdio.

## External API limitation in this execution environment

The running code attempted GitHub, ecosyste.ms and Scorecard requests. All three failed at DNS resolution because outbound networking is disabled for the code container. The application correctly retained the run and returned structured, retryable provider errors instead of crashing.

The external API contracts and selected live endpoints were checked separately using the available network tools. This is not represented as an end-to-end live integration run from the application process.

See `E2E_RESULTS.json` for machine-readable evidence.
