from __future__ import annotations

import datetime as dt
import uuid

from sqlalchemy import DateTime, Float, ForeignKey, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from atlas.db import Base


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex}"


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.UTC)


class Resource(Base):
    __tablename__ = "resources"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("res"))
    input_value: Mapped[str] = mapped_column(Text, nullable=False)
    canonical_url: Mapped[str] = mapped_column(Text, nullable=False, unique=True, index=True)
    resource_type: Mapped[str] = mapped_column(String(32), nullable=False, index=True)
    display_name: Mapped[str] = mapped_column(Text, nullable=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    runs: Mapped[list[AnalysisRun]] = relationship(back_populates="resource")


class AnalysisRun(Base):
    __tablename__ = "analysis_runs"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("run"))
    resource_id: Mapped[str] = mapped_column(ForeignKey("resources.id"), index=True)
    profile: Mapped[str] = mapped_column(String(32), default="standard")
    status: Mapped[str] = mapped_column(String(32), default="queued", index=True)
    started_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    completed_at: Mapped[dt.datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    errors_json: Mapped[str] = mapped_column(Text, default="[]")

    resource: Mapped[Resource] = relationship(back_populates="runs")
    observations: Mapped[list[Observation]] = relationship(
        back_populates="run", cascade="all, delete-orphan"
    )
    findings: Mapped[list[Finding]] = relationship(back_populates="run", cascade="all, delete-orphan")


class Observation(Base):
    __tablename__ = "observations"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("obs"))
    run_id: Mapped[str] = mapped_column(ForeignKey("analysis_runs.id"), index=True)
    field: Mapped[str] = mapped_column(String(255), index=True)
    value_json: Mapped[str] = mapped_column(Text, nullable=False)
    source: Mapped[str] = mapped_column(String(100), index=True)
    source_url: Mapped[str | None] = mapped_column(Text, nullable=True)
    confidence: Mapped[float] = mapped_column(Float, default=1.0)
    observed_at: Mapped[dt.datetime] = mapped_column(DateTime(timezone=True), default=utcnow)

    run: Mapped[AnalysisRun] = relationship(back_populates="observations")


class Finding(Base):
    __tablename__ = "findings"

    id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: new_id("find"))
    run_id: Mapped[str] = mapped_column(ForeignKey("analysis_runs.id"), index=True)
    finding_type: Mapped[str] = mapped_column(String(100), index=True)
    severity: Mapped[str] = mapped_column(String(16), index=True)
    title: Mapped[str] = mapped_column(Text)
    detail: Mapped[str] = mapped_column(Text)
    classification: Mapped[str] = mapped_column(String(32), default="derived_metric")
    confidence: Mapped[float] = mapped_column(Float, default=1.0)

    run: Mapped[AnalysisRun] = relationship(back_populates="findings")
