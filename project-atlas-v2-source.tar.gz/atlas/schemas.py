from __future__ import annotations

import datetime as dt
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class ResourceCreate(BaseModel):
    input: str = Field(min_length=1, max_length=4096)


class ResourceOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    input_value: str
    canonical_url: str
    resource_type: str
    display_name: str
    created_at: dt.datetime


class AnalysisCreate(BaseModel):
    profile: Literal["quick", "standard", "deep"] = "standard"


class AnalysisOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    resource_id: str
    profile: str
    status: str
    started_at: dt.datetime | None
    completed_at: dt.datetime | None
    errors: list[dict[str, Any]] = Field(default_factory=list)


class ObservationOut(BaseModel):
    id: str
    run_id: str
    field: str
    value: Any
    source: str
    source_url: str | None
    confidence: float
    observed_at: dt.datetime


class FindingOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: str
    run_id: str
    finding_type: str
    severity: str
    title: str
    detail: str
    classification: str
    confidence: float
