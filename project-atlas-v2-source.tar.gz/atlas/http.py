from __future__ import annotations

import httpx

from atlas.config import settings


def make_client() -> httpx.Client:
    headers = {"User-Agent": settings.user_agent, "Accept": "application/json"}
    if settings.github_token:
        headers["Authorization"] = f"Bearer {settings.github_token}"
    return httpx.Client(timeout=settings.request_timeout, headers=headers, follow_redirects=True)
